    
    <div class="shop-wrapper flex justify-center items-center md:mt-0 mt-[8vw] px-[4vw] pb-[2vw]">
        <div class="text-right">
            <a href="{{ route('product.create') }}" class="btn btn-primary">Create</a>
        </div>
        <div class="shop-list flex items-center gap-[5vw] md:gap-[2.7vw] carousel slide  md:my-0 my-[5vw] pb-0 md:pb-[6vw]" data-ride="carousel" id="myCarousel">
        </div>
    </div>
</div>
</div>